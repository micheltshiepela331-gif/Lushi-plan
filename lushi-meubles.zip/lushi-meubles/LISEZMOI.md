# Lushi Meubles — le catalogue de meubles réalistes de Lushi Plan

Ce dépôt contient les meubles 3D que Lushi Plan propose dans **🛋 Catalogue en ligne**.
Le téléphone télécharge un meuble **une seule fois** ; ensuite il marche sans internet.

## Mise en place (une seule fois)

1. Sur GitHub, crée un dépôt public nommé **lushi-meubles**.
2. Envoie-y tous les fichiers de ce dossier (garde le dossier caché `.github`).
3. Dans le dépôt : **Settings › Pages › Branch : main / (root) › Save**.
4. Dans **Settings › Actions › General**, choisis **Read and write permissions** puis **Save**.

L'adresse du catalogue sera : `https://micheltshiepela331-gif.github.io/lushi-meubles/catalogue.json`
(c'est déjà l'adresse prévue dans Lushi Plan).

## Ajouter un meuble

1. Sur **polyhaven.com › Models**, choisis un meuble (licence CC0, utilisable même dans une application payante).
2. Télécharge-le au format **glTF**, en résolution **1K** (léger pour les téléphones). Tu obtiens un zip.
3. Décompresse le zip et place le dossier ici :
   `sources/<Catégorie>/<nom_du_meuble>/` — par exemple `sources/Salon/canape_03/`
4. Facultatif :
   - `nom.txt` dans ce dossier : le nom affiché (ex. « Canapé 3 places gris ») ;
   - `apercu.jpg` : une petite image pour la fiche du catalogue.
5. Envoie le dossier sur GitHub. La tâche automatique **« Construire le catalogue de meubles »**
   convertit le meuble (photos de couleur seulement, tout en un seul fichier .glb) et met à jour `catalogue.json`.
   Quelques minutes plus tard, le meuble apparaît dans Lushi Plan.

Catégories conseillées : Salon, Chambre, Cuisine, Salle à manger, Salle de bain, Bureau, Extérieur, Décoration.

## Bon à savoir

- Ne télécharge pas les versions 2K ou 4K : elles sont trop lourdes pour un téléphone.
- Les versions compressées (Draco) ne sont pas acceptées.
- Les meubles Poly Haven sont sous licence CC0 : pas d'obligation de citer l'auteur, mais le catalogue mentionne « Poly Haven » par respect.
- Pour lancer la conversion à la main : `node build.mjs` (Node.js 18 ou plus, aucune installation).
